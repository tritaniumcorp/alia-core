# ALIA Core MVP

Starter backend for ALIA AI using FastAPI + Supabase/Postgres.

## Included
- FastAPI app scaffold
- Chat endpoint
- Memory store + retrieve endpoints
- Command execution simulation endpoint
- SQL schema for core tables
- Environment template

## Quick start
1. Create a virtual environment.
2. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
3. Copy `.env.example` to `.env` and fill values.
4. Run the API:
   ```bash
   uvicorn app.main:app --reload
   ```
5. Open docs at `http://127.0.0.1:8000/docs`

## Suggested deployment
- Backend: Railway, Render, DigitalOcean, or your own VPS
- Database: Supabase Postgres
- Frontend: Vercel (Tritanium Command)

## Endpoints
- `GET /health`
- `POST /api/v1/chat`
- `POST /api/v1/memory/store`
- `POST /api/v1/memory/search`
- `POST /api/v1/command/execute`

## Notes
This is an MVP foundation. The `LLMService` is written so you can later swap providers or move to a proprietary model without changing the dashboard integration.
