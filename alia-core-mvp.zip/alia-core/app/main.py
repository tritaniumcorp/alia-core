from fastapi import FastAPI

from app.config import settings
from app.routes.api import router as api_router
from app.routes.health import router as health_router

app = FastAPI(title=settings.app_name)
app.include_router(health_router)
app.include_router(api_router)
