from typing import Any, Dict, List, Optional
from pydantic import BaseModel, Field


class HealthResponse(BaseModel):
    status: str
    app: str
    environment: str


class ChatRequest(BaseModel):
    user_id: str = Field(..., min_length=1)
    message: str = Field(..., min_length=1)
    conversation_id: Optional[str] = None


class ChatResponse(BaseModel):
    reply: str
    memory_hits: List[Dict[str, Any]] = []
    conversation_id: Optional[str] = None


class MemoryStoreRequest(BaseModel):
    user_id: str
    content: str
    category: str = "general"
    metadata: Dict[str, Any] = {}
    importance_score: int = Field(default=5, ge=1, le=10)


class MemoryStoreResponse(BaseModel):
    success: bool
    memory_id: Optional[int] = None


class MemorySearchRequest(BaseModel):
    user_id: str
    query: str
    limit: int = Field(default=5, ge=1, le=20)


class MemorySearchResponse(BaseModel):
    results: List[Dict[str, Any]]


class CommandExecuteRequest(BaseModel):
    user_id: str
    command_name: str
    payload: Dict[str, Any] = {}


class CommandExecuteResponse(BaseModel):
    success: bool
    status: str
    result: Dict[str, Any]
