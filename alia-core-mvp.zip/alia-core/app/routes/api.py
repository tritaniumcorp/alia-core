from fastapi import APIRouter

from app.models.schemas import (
    ChatRequest,
    ChatResponse,
    CommandExecuteRequest,
    CommandExecuteResponse,
    MemorySearchRequest,
    MemorySearchResponse,
    MemoryStoreRequest,
    MemoryStoreResponse,
)
from app.services.command_service import CommandService
from app.services.llm_service import LLMService
from app.services.memory_service import MemoryService

router = APIRouter(prefix="/api/v1", tags=["alia"])


@router.post("/memory/store", response_model=MemoryStoreResponse)
def store_memory(request: MemoryStoreRequest) -> MemoryStoreResponse:
    memory_id = MemoryService.store_memory(
        user_id=request.user_id,
        content=request.content,
        category=request.category,
        metadata=request.metadata,
        importance_score=request.importance_score,
    )
    return MemoryStoreResponse(success=True, memory_id=memory_id)


@router.post("/memory/search", response_model=MemorySearchResponse)
def search_memory(request: MemorySearchRequest) -> MemorySearchResponse:
    results = MemoryService.search_memory(
        user_id=request.user_id,
        query=request.query,
        limit=request.limit,
    )
    return MemorySearchResponse(results=results)


@router.post("/chat", response_model=ChatResponse)
def chat(request: ChatRequest) -> ChatResponse:
    memory_hits = MemoryService.search_memory(
        user_id=request.user_id,
        query=request.message,
        limit=3,
    )
    reply = LLMService.generate_reply(request.message, memory_hits)
    return ChatResponse(reply=reply, memory_hits=memory_hits, conversation_id=request.conversation_id)


@router.post("/command/execute", response_model=CommandExecuteResponse)
def execute_command(request: CommandExecuteRequest) -> CommandExecuteResponse:
    result = CommandService.execute(
        user_id=request.user_id,
        command_name=request.command_name,
        payload=request.payload,
    )
    return CommandExecuteResponse(success=True, status="simulated", result=result)
