from typing import Any, Dict

from app.db import get_db


class CommandService:
    @staticmethod
    def execute(user_id: str, command_name: str, payload: Dict[str, Any]) -> Dict[str, Any]:
        # Simulated execution for MVP.
        result = {
            "executed": True,
            "command_name": command_name,
            "payload": payload,
            "mode": "simulation",
            "message": f"Command '{command_name}' logged successfully.",
        }

        with get_db() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    """
                    INSERT INTO commands_executed (user_id, command_name, payload, status)
                    VALUES (%s, %s, %s::jsonb, %s)
                    """,
                    (user_id, command_name, str(payload).replace("'", '"'), "simulated"),
                )

        return result
