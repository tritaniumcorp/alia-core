from typing import Any, Dict, List

from app.config import settings


class LLMService:
    @staticmethod
    def generate_reply(user_message: str, memory_hits: List[Dict[str, Any]]) -> str:
        # Stub provider for MVP foundation.
        # Replace this method with your chosen LLM provider integration.
        if settings.llm_provider == "stub":
            if memory_hits:
                memory_summary = "; ".join(hit["content"] for hit in memory_hits[:3])
                return (
                    f"ALIA online. I found relevant memory context: {memory_summary}. "
                    f"Your request was: {user_message}"
                )
            return f"ALIA online. I received your request: {user_message}"

        return "ALIA provider configured, but integration method has not been implemented yet."
