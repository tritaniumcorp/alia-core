import json
from typing import Any, Dict, List

from app.db import get_db


class MemoryService:
    @staticmethod
    def store_memory(user_id: str, content: str, category: str, metadata: Dict[str, Any], importance_score: int) -> int:
        with get_db() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    """
                    INSERT INTO memory_logs (user_id, content, category, metadata, importance_score)
                    VALUES (%s, %s, %s, %s::jsonb, %s)
                    RETURNING id
                    """,
                    (user_id, content, category, json.dumps(metadata), importance_score),
                )
                row = cur.fetchone()
                return int(row["id"])

    @staticmethod
    def search_memory(user_id: str, query: str, limit: int = 5) -> List[Dict[str, Any]]:
        like_query = f"%{query}%"
        with get_db() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    """
                    SELECT id, user_id, content, category, metadata, importance_score, created_at
                    FROM memory_logs
                    WHERE user_id = %s
                      AND (content ILIKE %s OR category ILIKE %s)
                    ORDER BY importance_score DESC, created_at DESC
                    LIMIT %s
                    """,
                    (user_id, like_query, like_query, limit),
                )
                return list(cur.fetchall())
